using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine.SocialPlatforms.Impl;

public class Scoring : MonoBehaviour
{
    public static Scoring instance;
    //hier wordt de text gemaakt zodat ik hem later kan linken aan de legacy tekst in unity   
    public Text coins;
    //de score van de coins wordt hier aangemaakt en nu op 0 gezet
    int coinsScore = 0;

    //in een void awake worden variabelen ingesteld voordat de aplicatie start
    private void Awake()
    {
        instance = this;
    }
    public void Start()
    {
        //in deze functie worden de punten in de text gezet in unity
        coins.text = coinsScore.ToString() + " punten";
    }

    public void CoinPickup()
    {
        //zodra er een coin opgepakt wordt wordt deze method aangeroepen in de class: "CoinPickup", er wordt een coin bij toegevoegd aan de score en dat wordt daarna geprint in unity
        coinsScore += 1;
        coins.text = coinsScore.ToString() + " punten";
        //als alle coins zijn opgepakt, in dit geval 18, laad unity scene nummer 2, de mainmenu
        if (coinsScore == 19)
        {
            SceneManager.LoadScene(2);
        }
    }
}
