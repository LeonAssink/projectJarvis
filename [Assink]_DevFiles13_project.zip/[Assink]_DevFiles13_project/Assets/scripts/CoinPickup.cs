using UnityEngine;
public class CoinPickup : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D collision)
    {
        //als de player colide met de box colider van de coin wordt de coin vernietigd
        if (collision.CompareTag("Player"))
        {
            //hier wordt de script: "Scoring" gezocht en gevonden
            FindObjectOfType<Scoring>();
            //de gameObject die gelinked is, in dit geval de munt/coin, wordt verwijderd zodra de iets met de tag: "Player" hem aanraakt
            Destroy(gameObject);
            //als deze method wordt aangeroepen wordt het verstuurd naar de method: "CoinPickup"
            Scoring.instance.CoinPickup();
        }
    }
}
