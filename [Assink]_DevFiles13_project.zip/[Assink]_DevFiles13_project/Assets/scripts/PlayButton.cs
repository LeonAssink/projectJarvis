using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayButton : MonoBehaviour
{
    //waneer de button: "PLAY" wordt ingedrukt laad unity de scene: "SampleScene" in.
    public void ButtonPress()
    {
        SceneManager.LoadScene(1);
    }
}
