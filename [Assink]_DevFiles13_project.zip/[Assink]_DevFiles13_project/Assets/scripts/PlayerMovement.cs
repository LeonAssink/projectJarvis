using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerMovement : MonoBehaviour
{
    //hier wordt de rigidbody gemaakt zodat hij gelinked kan worden
    Rigidbody2D rigidBody2d;
    //dit is de force die je krijgt als je charachter springt
    float jumpForce = 7;
    //dit is de walking speed van de charachter
    [SerializeField] float speed = 7;

    //de start functie wordt bij het opstarten een keer aangeroepen en dan niet meer
    private void Start()
    {
        //hier wordt de rigid body gelinked aan de rigidbody die de player heeft
        rigidBody2d = GetComponent<Rigidbody2D>();
    }

    //deze method wordt elke frame van de game opgeroepen
    private void Update()
    {
        //dit is als de player over de x-as beweegt, de horizontal wordt vermenigdvuldigd met de speed die eerder is aangemaakt
        float xMove = Input.GetAxisRaw("Horizontal") * speed;

        //dit is een raycast die gemaakt wordt in/onder de player, hij begint vanaf binnen en gaat met 0.55 onder de player zitten
        //als de raycast de grond raakt (tilemap in dit geval) kan de player springen, anders niet
        RaycastHit2D hit = Physics2D.Raycast(transform.position, Vector2.down, 0.55f);
        rigidBody2d.velocity = new Vector2(xMove, rigidBody2d.velocity.y);
        if (hit.collider != null)
        {
            if (hit.collider.name == "Tilemap" && Input.GetKeyDown(KeyCode.Space))
            {
                rigidBody2d.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
            }
        }
    }
    //deze method wordt aangeroepen als de player in de boxcolider komt die om het level heen is geplaatst
    private void OnTriggerEnter2D(Collider2D collision)
    {
        //als de player out of bounds raakt (tag is out of bounds genoemd want handig) dan laadt unity de scene die is aangegeven hier onder
        if (collision.tag == "OutOfBounds")
        {
            SceneManager.LoadScene(1);
        }
    }
}
